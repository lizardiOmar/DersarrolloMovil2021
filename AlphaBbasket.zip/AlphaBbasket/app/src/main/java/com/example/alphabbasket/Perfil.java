package com.example.alphabbasket;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.alphabbasket.model.Cliente;
import com.example.alphabbasket.model.Constantes;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Perfil extends AppCompatActivity {
    private Cliente cliente;
    private Button buttonEliminarCuenta, buttonEditarCuenta;
    private TextView textViewNombre, textViewApellidos, textViewCorreo, textViewEdad, textViewClave;
    private Context c=this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);
        iniciarComponentes();
        getCliente();
        agregarEventos();
    }

    private void agregarEventos() {
        buttonEliminarCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(c);
                builder.setTitle("Eliminar cuenta");
                builder.setMessage(cliente.getNombres()+" de verdad deseas eliminar tu cuenta de B-basket?");
                builder.setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Bundle extras = getIntent().getExtras();
                        String correo = extras.getString("correo");
                        String uri =  Constantes.clientes+"/?correo="+correo;
                        RequestQueue queue = Volley.newRequestQueue(Perfil.this);
                        StringRequest stringRequest = new StringRequest(Request.Method.DELETE, uri,
                                new Response.Listener<String>() {
                                    @Override
                                    public void onResponse(String ServerResponse) {
                                        Toast.makeText(Perfil.this, ServerResponse, Toast.LENGTH_LONG).show();
                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError volleyError) {
                                        Toast.makeText(Perfil.this, volleyError.toString(), Toast.LENGTH_LONG).show();
                                    }
                                });
                        // Creating RequestQueue.
                        RequestQueue requestQueue = Volley.newRequestQueue(Perfil.this);
                        // Adding the StringRequest object into requestQueue.
                        requestQueue.add(stringRequest);
                        Intent i = new Intent(getApplicationContext(), RegistroActivity.class );
                        startActivity(i);
                        finish();
                    }

                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });
        buttonEditarCuenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle extras = getIntent().getExtras();
                String correo = extras.getString("correo");
                Intent i = new Intent(getApplicationContext(), EditarPerfilActivity.class );
                i.putExtra("correo", correo);
                startActivity(i);
                finish();
            }
        });
    }

    private void getCliente() {
        Bundle extras = getIntent().getExtras();
        String correo = extras.getString("correo");
        String uri =  Constantes.clientes+"/?correo="+correo;
        RequestQueue queue = Volley.newRequestQueue(Perfil.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, uri,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Toast.makeText(Perfil.this, response, Toast.LENGTH_LONG).show();
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String stringCliente=jsonResponse.getString("cliente");


                            JSONObject jsonCliente = new JSONObject(stringCliente);
                            //Integer id=jsonCliente.getInt("id");
                            cliente=new Cliente(
                                    jsonCliente.getString("id"),
                                    jsonCliente.getString("nombres"),
                                    jsonCliente.getString("apellidos"),
                                    jsonCliente.getString("correo"),
                                    jsonCliente.getString("edad"),
                                    jsonCliente.getString("clave"));
                            textViewNombre.setText(cliente.getNombres());
                            textViewApellidos.setText(cliente.getApellidos());
                            textViewCorreo.setText(cliente.getCorreo());
                            textViewEdad.setText(cliente.getEdad());
                            textViewClave.setText(cliente.getContrasena());

                        } catch (JSONException ex) {

                            Toast.makeText(Perfil.this, ex.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Perfil.this, error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
        queue.add(stringRequest);
    }
    private void iniciarComponentes(){
        this.buttonEliminarCuenta=(Button)findViewById(R.id.btnEliminar);
        this.buttonEditarCuenta=(Button)findViewById(R.id.buttonEditarPerfil);
        
        this.textViewNombre=(TextView)findViewById(R.id.nombre_text);
        this.textViewApellidos=(TextView)findViewById(R.id.apellidos_text);
        this.textViewCorreo=(TextView)findViewById(R.id.correo_text);
        this.textViewEdad=(TextView)findViewById(R.id.edad_text);
        this.textViewClave=(TextView)findViewById(R.id.contrasena_text);
    }
}