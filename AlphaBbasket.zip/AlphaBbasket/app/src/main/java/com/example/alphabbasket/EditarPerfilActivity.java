package com.example.alphabbasket;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.alphabbasket.model.Cliente;
import com.example.alphabbasket.model.Constantes;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EditarPerfilActivity extends AppCompatActivity {

    private Cliente clienteOld;
    private EditText editTextNombres, editTextApellidos, editTextEdad;
    private Button buttonGuardar,buttonCancelar, buttonCambiarClave;
    private Boolean flag=false;
    private  String nombresNew, apellidosNew, edadNew;
    private String uri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_perfil);
        getCliente();
        iniciarComponentes();
        agregarEventos();
    }

    private void agregarEventos() {
        buttonCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getApplicationContext(), Perfil.class );
                Bundle extras = getIntent().getExtras();
                String correo = extras.getString("correo");
                i.putExtra("correo", correo);
                startActivity(i);
                finish();
            }
        });
        buttonGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nombresNew=editTextNombres.getText().toString().trim();
                apellidosNew=editTextApellidos.getText().toString().trim();
                edadNew=editTextEdad.getText().toString().trim();
                if(!nombresNew.isEmpty()&& !nombresNew.equals(clienteOld.getNombres())){
                    if(!apellidosNew.isEmpty()&& !apellidosNew.equals(clienteOld.getApellidos())){
                        if(!edadNew.isEmpty()&& !edadNew.equals(clienteOld.getEdad())){
                            flag=true;
                            uri=  Constantes.clientes+"?nombres="+nombresNew+"&?apellidos="+apellidosNew+"&?edad="+edadNew+"&?correo="+clienteOld.getCorreo();
                            //Toast.makeText(EditarPerfilActivity.this, uri, Toast.LENGTH_LONG).show();

                        }else{
                            editTextEdad.setError("No has cambiado la edad.");
                        }
                    }else{
                        editTextApellidos.setError("No has cambiado los apellidos.");
                    }
                }else{
                    editTextNombres.setError("No has cambiado el nombre.");
                }
                if(flag){
                    RequestQueue queue = Volley.newRequestQueue(EditarPerfilActivity.this);
                    StringRequest stringRequest = new StringRequest(Request.Method.PUT, uri,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    Toast.makeText(EditarPerfilActivity.this, response, Toast.LENGTH_LONG).show();
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(EditarPerfilActivity.this, error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                        }
                    }){
                        @Override
                        protected Map<String, String> getParams() {
                            // Creating Map String Params.
                            Map<String, String> params = new HashMap<String, String>();
                            // Adding All values to Params.

                            params.put("nombres", nombresNew);
                            params.put("apellidos", apellidosNew);
                            params.put("edad", edadNew);
                            params.put("correo", clienteOld.getCorreo());
                            return params;
                        }
                    };
                    queue.add(stringRequest);

                }else{

                }
            }
        });
    }

    private void iniciarComponentes() {
        this.editTextNombres=(EditText)findViewById(R.id.editTextNombresE);

        this.editTextApellidos=(EditText)findViewById(R.id.editTextApellidosE);


        this.editTextEdad=(EditText)findViewById(R.id.editTextEdadE);

        this.buttonCancelar=(Button)findViewById(R.id.buttonCancelar);
        this.buttonGuardar=(Button)findViewById(R.id.buttonGuardar);

    }

    private void getCliente() {
        Bundle extras = getIntent().getExtras();
        String correo = extras.getString("correo");
        String uri =  Constantes.clientes+"/?correo="+correo;
        RequestQueue queue = Volley.newRequestQueue(EditarPerfilActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, uri,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        //Toast.makeText(EditarPerfilActivity.this, response, Toast.LENGTH_LONG).show();
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String stringCliente=jsonResponse.getString("cliente");


                            JSONObject jsonCliente = new JSONObject(stringCliente);
                            //Integer id=jsonCliente.getInt("id");
                            clienteOld =new Cliente(
                                    jsonCliente.getString("id"),
                                    jsonCliente.getString("nombres"),
                                    jsonCliente.getString("apellidos"),
                                    jsonCliente.getString("correo"),
                                    jsonCliente.getString("edad"),
                                    jsonCliente.getString("clave"));
                                    editTextEdad.setHint(clienteOld.getEdad());
                                    editTextApellidos.setHint(clienteOld.getApellidos());
                                    editTextNombres.setHint(clienteOld.getNombres());



                        } catch (JSONException ex) {
                            Toast.makeText(EditarPerfilActivity.this, ex.getLocalizedMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(EditarPerfilActivity.this, error.getLocalizedMessage(), Toast.LENGTH_LONG).show();
            }
        });
        queue.add(stringRequest);
    }
}