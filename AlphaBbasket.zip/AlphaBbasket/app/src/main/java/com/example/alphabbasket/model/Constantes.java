package com.example.alphabbasket.model;

public class Constantes {
    public static final String claveEncriptacion = "secreto!";
    public static final String urlCrearCliente = "http://192.168.1.102:80/Bbasket2021/agregar_cliente.php";
    public static final String urlGetPassCliente = "http://192.168.1.102:80/Bbasket2021/getPass_byCorreo_cliente.php";
    public static final String urlAccederCliente = "http://192.168.1.102:80/Bbasket2021/login_cliente.php";
    public static final String urlUpdateNombre = "http://192.168.1.102:80/Bbasket2021/update_cliente_nombre.php";
    public static final String urlDleteCliente = "http://192.168.1.102:80/Bbasket2021/delete_cliente.php";

    public static final String localCrearCliente = "http://192.168.1.102/CRUD_API/CLIENTE/alta_cliente.php";
    public static final String localGetPassCliente = "http://192.168.1.102/CRUD_API/CLIENTE/login_cliente.php";
    public static final String localPerfilCliente = "http://192.168.1.102/CRUD_API/CLIENTE/get_cliente_byCorreo.php";

    public static final String clientes = "http://192.168.1.102/API/clientes.php";

}
