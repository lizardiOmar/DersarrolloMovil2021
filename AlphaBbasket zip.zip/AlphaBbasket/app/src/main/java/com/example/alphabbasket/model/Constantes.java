package com.example.alphabbasket.model;

public class Constantes {
    public static final String claveEncriptacion = "secreto!";

    public static final String clientes = "http://192.168.1.102/API/clientes.php";
    public static final String direcciones = "http://192.168.1.102/API/direcciones.php";

}
