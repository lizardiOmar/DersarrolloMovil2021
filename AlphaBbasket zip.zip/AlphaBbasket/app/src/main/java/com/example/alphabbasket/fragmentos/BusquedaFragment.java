package com.example.alphabbasket.fragmentos;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;

import com.example.alphabbasket.R;
import com.example.alphabbasket.model.CustomSpinnerAdapter;
import com.example.alphabbasket.model.RecyclerViewAdapterMarca;

public class BusquedaFragment extends Fragment {
    private RecyclerView recyclerView;
    private RecyclerViewAdapterMarca recyclerViewAdapterMarca;
    private String[] mDataset={"Marca 1","Marca 2","Marca 3","Marca 4","Marca 5","Marca 6"};
    private Spinner spinnerCategoria;
    private final String[] categorias = { "...", "Lácteos", "Carnes", "Huevos", "Grasas y aceites", "Frutas", "Verduras", "Cereales y semillas", "Azucares y dulces", "Pan", "Otros"};
    private RecyclerView.LayoutManager layoutManager;
    public static BusquedaFragment newInstance() {
        return new BusquedaFragment();
    }
    private CustomSpinnerAdapter customAdapter;
    private TextView textViewResultado;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_busqueda, container, false);
        spinnerCategoria = (Spinner) view.findViewById(R.id.spinnerCategorias);
        customAdapter=new CustomSpinnerAdapter(view.getContext(), categorias);
        recyclerView=(RecyclerView)view.findViewById(R.id.recyclerViewMarcas);
        recyclerViewAdapterMarca=new RecyclerViewAdapterMarca(mDataset);
        textViewResultado=(TextView)view.findViewById(R.id.textViewResultadoBusqueda);
        recyclerView.setAdapter(recyclerViewAdapterMarca);
        layoutManager=new GridLayoutManager(getActivity(), 3);
        recyclerView.setLayoutManager(layoutManager);
        spinnerCategoria.setAdapter(customAdapter);
        spinnerCategoria.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                textViewResultado.setText(rv.getId()+"---ID");
            }

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {

            }
        });
        return view;
    }
}